public class Livro {
    private String titulo;
    private int id;
    private String anoPublicacao;
    private String autor;

    public Livro(String titulo, String autor, String anoPublicacao) {
        this.titulo = titulo;
        this.autor = autor;
        this.anoPublicacao = anoPublicacao;
        this.id = Livro.getContador() + 1;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getAnoPublicacao() {
        return anoPublicacao;
    }

    public void setAnoPublicacao(String anoPublicacao) {
        this.anoPublicacao = anoPublicacao;
    }

    public String getAutor() {
        return autor;
    }

    public void setAutor(String autor) {
        this.autor = autor;
    }

    public static int getContador() {
        return Livro.contador;
    }

    public static void setContador(int contador) {
        Livro.contador = contador;
    }

    private static int contador = 0;

    @Override
    public String toString() {
        return "Livro [titulo=" + titulo + ", id=" + id + "]";
    }
}