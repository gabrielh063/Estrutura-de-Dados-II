import java.util.LinkedList;

public class Biblioteca {
    private LinkedList<Livro> livros;
    private LinkedList<Usuario> usuarios;

    public Biblioteca() {
        livros = new LinkedList<>();
        usuarios = new LinkedList<>();
    }

    public void adicionarLivro(Livro livro) {
        System.out.println("Adicionando Livro...");
        if (!livros.contains(livro)) {
            livros.add(livro);
            System.out.println("Livro '" + livro.getTitulo() + "' adicionado com sucesso!\n");
        } else {
            System.out.println("O livro '" + livro.getTitulo() + "' já existe na biblioteca!\n");
        }
    }

    public Livro buscarLivro(int idLivro) {
        System.out.println("Buscando Livro...");
        for (Livro livro : livros) {
            if (livro.getId() == idLivro) {
                System.out.println("Resultado da busca:");
                System.out.println(livro + "\n");
            }
        }
        return null;
    }

    public void removerLivro(int idLivro) {
        System.out.println("Removendo Livro...");
        for (Livro livro : livros) {
            if (livro.getId() == idLivro) {
                livros.remove(livro);
                System.out.println("Livro '" + livro + "' removido com sucesso!\n");
            }
        }
    }

    public void listarLivros() {
        System.out.println("Listando Livros...");
        System.out.println("ID\tTitulo");
        livros.sort((livro1, livro2) -> Integer.compare(livro1.getId(), livro2.getId()));
        for (Livro livro : livros) {
            String aux = livro.getId() + "\t" + livro.getTitulo();
            System.out.println(aux);
        }
        System.out.println();
    }

    public void adicionarUsuario(Usuario usuario) {
        System.out.println("Adicionando Usuário...");
        if (usuarios.contains(usuario)) {
            System.out.println("O usuário " + usuario.getNome() + " já está cadastrado na biblioteca.");
        } else {
            usuarios.add(usuario);
            System.out.println("O usuário " + usuario.getNome() + " foi cadastrado com sucesso.");
        }
        System.out.println();
    }

    public Usuario buscarUsuario(int id) {
        System.out.println("Consultando Usuário...");
        for (Usuario usuario : usuarios) {
            if (usuario.getId() == id) {
                return usuario;
            }
        }
        System.out.println("Usuário não cadastrado");
        System.out.println();
        return null;
    }

    public void removerUsuario(int id) {
        System.out.println("Removendo Usuário...");
        for (Usuario usuario : usuarios) {
            if (usuario.getId() == id) {
                usuarios.remove(usuario);
                System.out.println("O cadastro do usuário " + usuario.getNome() + " foi removido.");
            }
        }
        System.out.println();
    }

    public void listarUsuarios() {
        System.out.println("Listando Usuários...");
        System.out.println("ID\tNome\tE-mail");
        for (Usuario usuario : usuarios) {
            String aux = usuario.getId() + "\t" + usuario.getNome() + "\t" + usuario.getEmail();
            System.out.println(aux);
        }
        System.out.println();
    }
}