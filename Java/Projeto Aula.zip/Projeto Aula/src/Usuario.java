public class Usuario {
    private int id;
    private String nome;
    private String email;

    public Usuario(String nome, String email) {
        this.nome = nome;
        this.email = email;
        this.id = Usuario.getContador() + 1;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getNome() {
        return nome;
    }

    public String getEmail() {
        return email;
    }

    public int getId() {
        return id;
    }

    public static int getContador() {
        return Usuario.contador;
    }

    public static void setContador(int contador) {
        Usuario.contador = contador;
    }

    private static int contador = 0;

    @Override
    public String toString() {
        return "Id: " + getId() + " Nome: " + getNome() + " E-mail: " + getEmail();
    }
}